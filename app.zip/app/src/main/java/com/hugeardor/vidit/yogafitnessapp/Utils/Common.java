package com.hugeardor.vidit.yogafitnessapp.Utils;

/**
 * Created by vidit on 28/12/17.
 */

public class Common {

    public static  final  int TIME_LIMIT_EASY = 10000;
    public static  final  int TIME_LIMIT_MEDIUM = 20000;
    public static  final  int TIME_LIMIT_HARD = 30000;





}
