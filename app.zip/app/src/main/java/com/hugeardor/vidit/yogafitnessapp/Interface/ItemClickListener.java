package com.hugeardor.vidit.yogafitnessapp.Interface;

import android.view.View;

/**
 * Created by vidit on 26/12/17.
 */

public interface ItemClickListener {

    void onClick(View view , int position) ;
}
