package com.hugeardor.vidit.yogafitnessapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.hugeardor.vidit.yogafitnessapp.Custom.WorkoutDoneDecorator;
import com.hugeardor.vidit.yogafitnessapp.Database.YogaDB;
import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;

import java.util.Date;
import java.util.HashSet;
import java.util.List;

public class Calendar extends AppCompatActivity {


    MaterialCalendarView materialCalendarView;
    HashSet<CalendarDay> list = new HashSet<>();

    YogaDB yogaDB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        yogaDB = new YogaDB(this);
        materialCalendarView = (MaterialCalendarView)findViewById(R.id.calendar);

        //get all workout days from databse
        //convert it to hash set
        //then, display it on the calendar by decorator on the days included in the HashSet

        List<String> workoutDay = yogaDB.getWorkoutDays();
        HashSet<CalendarDay> convertedList = new HashSet<>();
        for(String value : workoutDay)
            convertedList.add(CalendarDay.from(new Date(Long.parseLong(value))));


        materialCalendarView.addDecorator(new WorkoutDoneDecorator(convertedList));

    }

}
